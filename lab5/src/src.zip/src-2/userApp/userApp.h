#ifndef __USER_APP_H__
#define __USER_APP_H__

//=======APP, user should define this==================================
//#error "TODO: 在这里设置合适的数值"
#define USER_TASK_NUM 4   // init + shell + mytsk0 + mytsk1 + ??

#endif
