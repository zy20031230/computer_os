#ifndef __I386_IRQS_H__
#define __I386_IRQS_H__

#include "myPrintk.h" 

void ignoreIntBody(void);

#endif
