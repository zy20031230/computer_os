#ifndef __I8259_H__
#define __I8259_H__

void init8259A(void);

#endif